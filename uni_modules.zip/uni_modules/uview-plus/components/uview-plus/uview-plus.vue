<template>
</template>

<template>
	<view></view>
</template>

<script>
	export default {
		
	}
</script>

<style>
</style>
