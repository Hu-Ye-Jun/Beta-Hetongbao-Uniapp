/*
 * @Author       : LQ
 * @Description  :
 * @version      : 1.0
 * @Date         : 2021-08-20 16:44:21
 * @LastAuthor   : LQ
 * @lastTime     : 2021-08-20 17:22:55
 * @FilePath     : /u-view2.0/uview-ui/libs/config/props/tabbarItem.js
 */
export default {
    //
    tabbarItem: {
        name: null,
        icon: '',
        badge: null,
        dot: false,
        text: '',
        badgeStyle: 'top: 6px;right:2px;'
    }
}
